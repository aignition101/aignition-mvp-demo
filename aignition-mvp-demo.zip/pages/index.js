export default function Home() {
  return (
    <div style={{ padding: 40 }}>
      <h1>AIgnition MVP Demo</h1>
      <p>這是智慧節能平台的原型展示畫面。</p>
    </div>
  );
}