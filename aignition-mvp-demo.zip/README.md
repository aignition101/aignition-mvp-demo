# AIgnition MVP Demo

這是用於智慧節能平台展示的最小可行產品（MVP）。

## 功能模擬
- 即時風機監控
- 節電數據展示
- AI預警提示

部署建議使用 Vercel，並搭配 GitHub 自動化更新。